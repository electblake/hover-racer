extends SceneTree
var failures := 0
func require(condition: bool, message: String) -> void:
	if not condition:
		failures += 1
		push_error(message)
func _initialize() -> void:
	call_deferred("check")
func frames(count: int) -> void:
	for i in range(count): await physics_frame
func check() -> void:
	var scene = load("res://Main.tscn").instantiate()
	root.add_child(scene)
	await frames(3)
	var ship = scene.get_node("SHIP")
	var space = scene.get_world_3d().direct_space_state
	var count := 0
	for z in range(-106,82,2):
		var road: Dictionary = ship.road_at(Vector3(55,12,z))
		require(not road.is_empty(),"Missing canyon road")
		if road.is_empty(): continue
		for x in [43.5,49.0,55.0,61.0,66.5]:
			var point := Vector3(x,road.position.y+.6,z)
			var obstacles = space.intersect_ray(PhysicsRayQueryParameters3D.create(point,point+Vector3.UP*12,2))
			require(obstacles.is_empty(),"Scenery/arch blocks road or camera at %s" % point)
			var query := PhysicsShapeQueryParameters3D.new()
			query.shape = ship.get_node("CollisionShape3D").shape
			query.transform = Transform3D(Basis.IDENTITY,Vector3(x,road.position.y+1.5,z))
			query.collision_mask = 2
			var hits = space.intersect_shape(query)
			require(hits.is_empty(),"Ship envelope hits canyon at %s" % point)
			count += 1
	# Model silhouette and independent visual response.
	require(ship.visual.mesh == null,"Old box must be replaced")
	require(ship.pod_visual.has_node("LeftEnginePod") and ship.pod_visual.has_node("RightEnginePod") and ship.pod_visual.has_node("TrailingCockpit"),"Twin engines and trailing cockpit")
	require(ship.engines.size()==2 and ship.engines[0].position.x<-.9 and ship.engines[1].position.x>.9,"Separated independent exhausts")
	for player in ship.engine_audio+[ship.wind_audio]:
		require(player.stream is AudioStreamWAV and player.stream.get_length()>1.9,"Audio loaded")
		require(player.stream.loop_mode==AudioStreamWAV.LOOP_FORWARD,"Audio must loop")
	ship.reset_visuals()
	ship.position = Vector3(55,2,60)
	ship.velocity = Vector3.ZERO
	var camera_rotation: Vector3 = ship.camera.rotation
	var collider_transform: Transform3D = ship.get_node("CollisionShape3D").transform
	Input.action_press("thrust")
	await frames(12)
	require(ship.engines[0].visible and ship.engines[1].visible,"Both exhausts share RT")
	require(not ship.engine_audio[0].playing and not ship.engine_audio[1].playing,"Engine audio must remain disabled under power")
	await frames(18)
	require(not ship.engine_audio[0].playing and not ship.engine_audio[1].playing and ship.wind_audio.playing,"Wind retained, engines disabled")
	require(ship.camera.position.z>ship.camera_rest_position.z+.9 and ship.camera.position.z<ship.camera_rest_position.z+ship.camera_pullback+ship.camera_kick_pullback+.01,"Restrained thrust pullback")
	require(ship.camera.rotation.is_equal_approx(camera_rotation),"Camera must not roll or shake")
	require(ship.get_node("CollisionShape3D").transform.is_equal_approx(collider_transform),"Visuals must not alter collider")
	Input.action_release("thrust")
	var coast_speed: float = Vector2(ship.velocity.x,ship.velocity.z).length()
	await frames(30)
	require(not ship.engine_audio[0].playing and not ship.engine_audio[1].playing,"Engine audio stops after release")
	require(ship.wind_audio.playing,"Wind must continue during coast")
	require(absf(Vector2(ship.velocity.x,ship.velocity.z).length()-maxf(coast_speed-ship.coast_deceleration*.5,0))<.3,"Coasting deceleration should stay predictable")
	require(ship.camera.position.distance_to(ship.camera_rest_position)<.08,"Camera returns on release")
	ship.reset_visuals()
	require(not ship.wind_audio.playing and not ship.engine_audio[0].playing and not ship.engine_audio[1].playing,"Reset stops all audio")
	require(ship.camera.position.is_equal_approx(ship.camera_rest_position),"Reset restores camera")
	print("Canyon/model: %d clear road/arch/ship envelopes, twin-pod silhouette, shared trigger exhaust, disabled engine audio, loop loading, coast wind, restrained camera and reset; failures=%d" % [count,failures])
	scene.queue_free()
	await process_frame
	# Allow the audio mixer to release stopped playback buffers before fast test exit.
	OS.delay_msec(120)
	await process_frame
	quit(0 if failures==0 else 1)
