extends SceneTree
var failures := 0
func require(condition: bool,message: String) -> void:
	if not condition:
		failures += 1
		push_error(message)
func frames(count: int) -> void:
	for i in range(count): await physics_frame
func _initialize() -> void:
	call_deferred("check")
func check() -> void:
	var scene = load("res://Main.tscn").instantiate()
	root.add_child(scene)
	await frames(3)
	var ship = scene.get_node("SHIP")
	ship.position = Vector3(55,2,70)
	ship.velocity = Vector3.ZERO
	ship.reset_visuals()
	Input.action_press("thrust")
	await frames(6)
	var speed: float = Vector2(ship.velocity.x,ship.velocity.z).length()
	require(speed>=29 and speed<=31,"Launch should reach ~30m/s in 0.1s versus prior 14.5m/s")
	require(ship.camera.position.z-ship.camera_rest_position.z>.25,"Prompt camera pullback on gas")
	require(ship.camera.fov-ship.camera_rest_fov>1,"Prompt FOV response on gas")
	var reached_cap := -1
	var max_pull := 0.0
	var max_fov := 0.0
	var prior_camera: Vector3 = ship.camera.position
	var prior_fov: float = ship.camera.fov
	for frame in range(24):
		await physics_frame
		var current: float = Vector2(ship.velocity.x,ship.velocity.z).length()
		if current>=ship.max_speed-.01 and reached_cap<0: reached_cap=frame+7
		require(current<=ship.max_speed+.01,"No speed overshoot")
		max_pull=maxf(max_pull,ship.camera.position.z-ship.camera_rest_position.z)
		max_fov=maxf(max_fov,ship.camera.fov-ship.camera_rest_fov)
		require(ship.camera.position.distance_to(prior_camera)<.2 and absf(ship.camera.fov-prior_fov)<1.5,"Camera onset must stay smooth")
		prior_camera=ship.camera.position
		prior_fov=ship.camera.fov
	require(reached_cap>0 and reached_cap<=22,"Cap should be reached in about 0.35 seconds")
	require(max_pull>.9 and max_pull<=1.5,"Stronger bounded pullback")
	require(max_fov>8 and max_fov<=12,"Stronger bounded FOV")
	var powered_fov: float = ship.camera.fov
	Input.action_release("thrust")
	await frames(30)
	require(ship.camera.position.distance_to(ship.camera_rest_position)<.08,"Camera returns when coasting")
	require(powered_fov-ship.camera.fov>4,"Clear power/coast FOV contrast")
	require(not ship.engines[0].visible and not ship.engines[1].visible,"Exhaust switches off on release")
	for pulse in range(6):
		Input.action_press("thrust")
		await frames(2)
		Input.action_release("thrust")
		await frames(2)
		require(Vector2(ship.velocity.x,ship.velocity.z).length()<=104.01,"Gas taps must not stack physical boosts")
		require(ship.throttle_kick<=1 and ship.camera.position.z-ship.camera_rest_position.z<=1.5,"Gas taps must not stack camera kick")
	ship.reset_visuals()
	require(ship.throttle_kick==0 and ship.previous_power==0 and ship.camera.position.is_equal_approx(ship.camera_rest_position),"Reset clears onset effect")
	print("Power contrast: %.1fm/s after 0.1s (prior 14.5); cap in %.2fs (52m/s cap previously ~0.18); pullback %.2fm, FOV +%.1f; release/tap bounds/reset; failures=%d" % [speed,float(reached_cap)/60,max_pull,max_fov,failures])
	scene.queue_free()
	await process_frame
	OS.delay_msec(120)
	await process_frame
	quit(0 if failures==0 else 1)
